//
//  RazorpayView.swift
//  HelAi2.0
//
//  Created by Aman Pratap Singh on 12/09/23.
//

import SwiftUI
import Razorpay

struct RazorpayView : UIViewControllerRepresentable {
    
    @State var razorKey : String = "rzp_test_k21YFw9jRRukBx"
    
    func makeUIViewController(context: UIViewControllerRepresentableContext<RazorpayView>) -> RazorViewController {
        let controller = RazorViewController()
        controller.razorKey = self.razorKey
        return controller
    }
    
    func updateUIViewController(_ uiViewController: RazorViewController, context: UIViewControllerRepresentableContext<RazorpayView>) {
        
    }
}

struct RazorpayView_Previews: PreviewProvider {
    static var previews: some View {
        RazorpayView(razorKey: "rzp_test_k21YFw9jRRukBx")
    }
}

class RazorViewController: UIViewController {
    
    //MARK: - INSTANCE VARIABLES
    private var razorpay:RazorpayCheckout?
    var razorKey = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        razorpay = RazorpayCheckout.initWithKey(razorKey, andDelegateWithData: self)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: animated)
        
        let options: [String:Any] = [
            "amount": "100",
            "currency": "INR",
            "description": "productDescription",
            "image": Image("HELAI2"),
            "name": "HELAI2.0",
            "prefill": [
                "contact": "contactNumber",
                "email": "email"
            ],
            "theme": [
                "color": "#F37254"
            ]
        ]
        razorpay?.open(options)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(false, animated: animated)
    }
}

extension RazorViewController: RazorpayPaymentCompletionProtocolWithData {
    func onPaymentSuccess(_ payment_id: String, andData response: [AnyHashable : Any]?) {
        FirebaseHelper.shared.setUserSubscription(subcribed: true)
        
        let alert = UIAlertController(title: "Paid to HELAI2.0", message: "Payment Success", preferredStyle: .alert)
        let action = UIAlertAction(title: "OK", style: .cancel, handler: { _ in
           
        })
        alert.addAction(action)
        self.present(alert, animated: true, completion: nil)
    }
    
    func onPaymentError(_ code: Int32, description str: String, andData response: [AnyHashable : Any]?) {
        let alert = UIAlertController(title: "Oops Payment Failed !!!", message: "\(code)\n\(str)", preferredStyle: .alert)
        let action = UIAlertAction(title: "OK", style: .cancel, handler: {_ in

        })
        alert.addAction(action)
        self.present(alert, animated: true, completion: nil)
    }
}
