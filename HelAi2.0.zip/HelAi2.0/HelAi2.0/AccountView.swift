//
//  AccountView.swift
//  HelAi2.0
//
//  Created by Aman Pratap Singh on 11/09/23.
//

import SwiftUI
import Firebase
import PhotosUI
import FirebaseAuth

struct AccountView: View {
    @State private var date = Date()
    @State private var adsSetting = true
    @State private var voicePicker = "Person1"
    let voicePacks = ["Person1", "Person2", "Person3", "Person4"]
    @State private var moveToLandingPage = false
    @State private var isUserSubscribed = false
    @State private var appRating = 0
    @State private var volumeReading: Double = 30.0
    @State private var isEditing = false
    
    var body: some View {
        NavigationView {
                Form {
                    NavigationLink(destination: SubAccountView()) {
                        HStack(spacing: 30) {
                            Image("HELAI2")
                                .resizable()
                                .clipped()
                                .frame(width: 100, height: 100, alignment: .center)
                                .clipShape(Circle())
                                .overlay(Circle().stroke(Color.blue, lineWidth: 2.0))
                            VStack {
                                Text("\(FirebaseAuth.Auth.auth().currentUser?.email ?? "No User Found")")
                                Text(isUserSubscribed ? "PREMIUM USER" : "NON PREMIUM USER")
                                    .foregroundColor(.red)
                            }
                        }
                    }
                    
                    Section {
                        LabeledContent("USER", value: "\(FirebaseAuth.Auth.auth().currentUser?.email ?? "No User Found")")
                        LabeledContent("SUBSCRIPTION", value: "\(isUserSubscribed)")
                    } header: {
                        Text("User Information")
                    }
//                    .listRowBackground(Color.red)
                    
                    
                    Section {
                        Toggle("ADS", isOn: $adsSetting)
                        Picker("VOICE PACK", selection: $voicePicker, content: {
                            ForEach(voicePacks, id: \.self) {
                                Text($0)
                            }
                        })
                    } header: {
                        Text("User configuration")
                    }
//                    .listRowBackground(Color.red)
                    
                    
                    Section {
                            DatePicker("D.O.B", selection: $date)
                        Stepper(value: $appRating, in: 0...5) {
                                                Text("APP RATING is \(appRating) out of 5")
                                            }
                    } header: {
                        Text("PERSONAL INFORMATION")
                    }
//                    .listRowBackground(Color.red)
                    
                    Section {
                        VStack {
                            Text("Application Volume  \(volumeReading, specifier: "%.2f")")
                                .foregroundColor(isEditing ? .red : .blue)
                            Slider(
                                value: $volumeReading,
                                in: 0...50,
                                step: 5,
                                onEditingChanged: { editing in
                                    isEditing = editing
                                },
                                minimumValueLabel: Text("0"),
                                maximumValueLabel: Text("50"),
                                label: {
                                    Text("Values from 0 to 50")
                                }
                            )
                        }
                        
                        Button("Unsubscribe", role: .destructive) {
                            isUserSubscribed = false
                            FirebaseHelper.shared.setUserSubscription(subcribed: false)
                        }
                        
                        Button("Log Out", role: .destructive) {
                            FirebaseHelper.shared.firebaseSignOut()
                            moveToLandingPage = true
                        }
                    }
                }
//                .scrollContentBackground(.hidden)
//                .background(.red)
                .navigationTitle("Account")
                .onAppear{
                    isUserSubscribed = UserDefaults.standard.bool(forKey: "isSubscribed")
                }
            
            NavigationLink("", destination: LandingPageView(), isActive: $moveToLandingPage)
        }
    }
}

struct AccountView_Previews: PreviewProvider {
    static var previews: some View {
        AccountView()
    }
}
