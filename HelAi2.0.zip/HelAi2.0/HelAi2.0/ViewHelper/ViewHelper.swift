//
//  ButtonHelper.swift
//  HelAi2.0
//
//  Created by Aman Pratap Singh on 06/09/23.
//

import SwiftUI

struct RoundButton: ViewModifier {
    func body(content: Content) -> some View {
        content
            .padding(.horizontal, 150)
            .frame(height: 45)
            .foregroundColor(.red)
            .background(.black)
            .cornerRadius(22)
            .overlay(
                RoundedRectangle(cornerRadius: 25)
                    .stroke(Color.white, lineWidth: 2)
            )
    }
}

struct RoundTextField: ViewModifier {
    
    func body(content: Content) -> some View {
        content
            .foregroundColor(.red)
            .frame(maxWidth: 340)
            .padding(11)
            .background(.black)
            .clipShape(RoundedRectangle(cornerRadius: 20))
            .overlay(
                RoundedRectangle(cornerRadius: 25)
                    .stroke(Color.white, lineWidth: 2)
            )
            .autocorrectionDisabled(true)
    }
}
