//
//  FirebaseHelper.swift
//  HelAi2.0
//
//  Created by Aman Pratap Singh on 06/09/23.
//

import Foundation
import Firebase
import Combine
import FirebaseFirestore

class FirebaseHelper {
    
    static let shared = FirebaseHelper()
    
    var accountCreateResponse = PassthroughSubject<Bool,Never>()
    var userLogInResponse = PassthroughSubject<Bool, Never>()
    
//  ACCOUNT CREATION
    func createUserAccount(email: String, password: String) {
        FirebaseAuth.Auth.auth().createUser(withEmail: email, password: password, completion: { result, error in
            result != nil
            ? self.accountCreateResponse.send(true)
            : self.accountCreateResponse.send(false)
        })
    }
    
//  ACCOUNT LOGIN
    func userLogIn(email: String, password: String) {
        FirebaseAuth.Auth.auth().signIn(withEmail: email, password: password, completion: { result, error in
            result != nil
            ? self.userLogInResponse.send(true)
            : self.userLogInResponse.send(false)
        })
    }
 
//  ACCOUNT SIGN OUT
    func firebaseSignOut() {
        try! FirebaseAuth.Auth.auth().signOut()
    }
    
//  SUBSCRIPTION SET
    func setUserSubscription(subcribed: Bool) {
        let db = Firestore.firestore()
        let ref = db.collection("Subscription").document(FirebaseAuth.Auth.auth().currentUser!.uid)
        ref.setData(["Subscribed": subcribed, "id": FirebaseAuth.Auth.auth().currentUser!.uid, "time": "\(Date())"])
        UserDefaults.standard.set(subcribed, forKey: "isSubscribed")
    }
    
//  SUBSCRIPTION GET
    func getIsUserSubscribed() {
        let db = Firestore.firestore()
        let ref = db.collection("Subscription").document(FirebaseAuth.Auth.auth().currentUser!.uid)
        ref.getDocument { value, error in
            let data = value?.data()
            UserDefaults.standard.set(data?["Subscribed"] as? Bool, forKey: "isSubscribed")
        }
    }
    
//  OBJECT DETECTION ATTEMPT SET
    func setUserObjectDetectionAttempt(attempt: Int) {
        let db = Firestore.firestore()
        let ref = db.collection("ObjectDetectionAttempt").document(FirebaseAuth.Auth.auth().currentUser!.uid)
        ref.setData(["attempts": attempt])
        UserDefaults.standard.set(attempt, forKey: "ObjectDetectionAttempt")
    }
    
//  OBJECT DETECTION ATTEMPY GET
    func getUserObjectDetectionAttempt() {
        let db = Firestore.firestore()
        let ref = db.collection("ObjectDetectionAttempt").document(FirebaseAuth.Auth.auth().currentUser!.uid)
        ref.getDocument { value, error in
            let data = value?.data()
            UserDefaults.standard.set(data?["attempts"], forKey: "ObjectDetectionAttempt")
        }
    }
    
//  SENTIMENT ANALYSIS ATTEMPT SET
    func setSentimentAnalysisAttempt(attempt: Int) {
        let db = Firestore.firestore()
        let ref = db.collection("SentimentAnalysisAttempt").document(FirebaseAuth.Auth.auth().currentUser!.uid)
        ref.setData(["attempts": attempt])
        UserDefaults.standard.set(attempt, forKey: "SentimentAnalysisAttempt")
    }
    
//  SENTIMENT ANAYLYSIS ATTEMPT GET
    func getSentimentAnalysisAttempt() {
        let db = Firestore.firestore()
        let ref = db.collection("SentimentAnalysisAttempt").document(FirebaseAuth.Auth.auth().currentUser!.uid)
        ref.getDocument { value, error in
            let data = value?.data()
            UserDefaults.standard.set(data?["attempts"], forKey: "SentimentAnalysisAttempt")
        }
    }
}
