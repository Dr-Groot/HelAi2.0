//
//  PremiumView.swift
//  HelAi2.0
//
//  Created by Aman Pratap Singh on 12/09/23.
//

import SwiftUI

struct PremiumView: View {
    @State var isUserSubscribed = false
        var body: some View {
        NavigationView {
            isUserSubscribed
            ? AnyView(SubscribedView())
            : AnyView(SubciptionView())
        }
        .onAppear {
            isUserSubscribed = UserDefaults.standard.bool(forKey: "isSubscribed")
        }
    }
}

struct SubscribedView: View {
    var body: some View {
        ZStack {
            LinearGradient(colors: [.red, .black],
                                  startPoint: .top,
                           endPoint: .bottom)
            .ignoresSafeArea()
            
            HStack(spacing: -10) {
                Text("Congratulations !!\nYOU ARE A PRO NOW")
                    .font(.custom("Livvic-Bold", size: 25))
                LottieView(lottieFile: "premium")
                    .frame(width: 100, height: 100)
            }
            .padding()
            .background(.red)
            .cornerRadius(55)
            
        }
    }
}

struct SubciptionView: View {
    @State var moveToRazorPay = false
    var body: some View {
        ZStack {
            LinearGradient(colors: [.white, .black],
                                  startPoint: .top,
                           endPoint: .bottom)
            .ignoresSafeArea()

            
            VStack {
                Spacer()
                
              Text("PREMIUM PLANS")
                    .font(.title.bold())
              HStack {
                  Text("SUBSCRIBE NOW")
                        .fontWeight(.bold)
                        .foregroundColor(.red)
                  Image(systemName: "crown")
                      .foregroundColor(.red)
              }
                
                HStack {
                    Spacer(minLength: 120)
                    Image(systemName: "arrow.left")
                        .foregroundColor(.red)
                    Text("MONTHLY\n $25")
                        .font(.custom("Livvic-Bold", size: 33))
                        .foregroundColor(.red)
                    Spacer()
                }
                .padding()
                
                HStack(spacing: -10) {
                    Text("BECOME A PRO")
                        .font(.custom("Livvic-Bold", size: 25))
                    LottieView(lottieFile: "premium")
                        .frame(width: 100, height: 100)
                }
                .padding()
                .background(.ultraThinMaterial)
                .cornerRadius(55)
                
                HStack {
                    Spacer(minLength: 120)
                    Image(systemName: "arrow.left")
                        .foregroundColor(.red)
                    Text("YEARLY\n $249")
                        .font(.custom("Livvic-Bold", size: 33))
                        .foregroundColor(.red)
                    Spacer()
                }
                .padding()
                
                Text("For unlimited access to the HeliAI Application. Subscribe today and achieve your goals with beautiful artificial intielligence features of getting perfect results for you.")
                      .padding()
                      .font(.custom("Livvic-Regular", size: 20))
                      .multilineTextAlignment(.center)
                      .foregroundColor(.white)
                                
                Text("Get $99.0 Discount on yearly pack and $49.0 on monthly pack.")
                      .padding()
                      .font(.custom("Livvic-Regular", size: 20))
                      .multilineTextAlignment(.center)
                      .foregroundColor(.red)
                
               VStack {
                    Spacer()
        
                }
            }
            
            PremiumButtonView() {
                moveToRazorPay = true
            }
            PremiumButtonView2() {
                moveToRazorPay = true
            }
            
            NavigationLink("", destination: RazorpayView(), isActive: $moveToRazorPay)
        }

    }
}

struct PremiumButtonView: View {
    @State var expanded = false
    @State var showDetails = false
    
    @State var offsetX: Double = -275
    @State var offsetY: Double = -300
    @State var height: Double = 100
    
    var click25: (() ->Void)?
    
    var body: some View {
        GeometryReader { g in
            VStack{
                VStack {
                    HStack {
                        Text("MONTHLY SUBSCRIPTION")
                            .font(.custom("Livvic-Medium", size: 17))
                            .padding(.leading)
                        Spacer()
                        
                        
                        Button(action: {
                            withAnimation(.linear(duration: 0.7)) {
                                showDetails.toggle()
                                if showDetails {
                                    height = 230
                                } else {
                                    height = 100
                                }
                            }
                        }, label: {
                            Text(showDetails ? "Cancel" : "Buy")
                        })
                        .buttonStyle(.borderedProminent)
                        .tint(.red)
                        .padding([.top, .bottom, .trailing])
                        
                        Button(action: {
                            withAnimation(.linear(duration: 0.7)) {
                                expanded.toggle()
                                if expanded {
                                    offsetX = 0
                                } else {
                                    offsetX = g.size.width  * -0.75
                                    if showDetails {
                                        showDetails = false
                                        height = 100
                                    }
                                }
                            }
                        }, label: {
                            Text(expanded ? "Hide" : "Buy Now")
                        })
                        .buttonStyle(.borderedProminent)
                        .tint(.red)
                        .padding([.top, .bottom])
                    }
                    .padding()
                    if showDetails {
                        VStack{
                            Text("Montly amount of money that you pay regularly to receive a service or magazine, or to belong to or support an organization")
                            Button {
                                click25?()
                            } label: {
                                Text("PAY $25")
                            }
                            .buttonStyle(.borderedProminent)
                            .tint(.red)
                        }
                        
                    }
                }
                .frame(minWidth: 100, idealWidth: .infinity, maxWidth: .infinity, minHeight: -200, idealHeight: height, maxHeight: height, alignment: .top)
//                    .border(Color(.lightGray), width: 2)
                .background(.ultraThinMaterial)
            }
            .offset(x: offsetX, y: 105.0)
            .onAppear(perform: {
                offsetX = g.size.width * -0.75
            })
        }
    }
}

struct PremiumButtonView2: View {
    @State var expanded = false
    @State var showDetails = false
    
    @State var offsetX: Double = -275
    @State var offsetY: Double = -300
    @State var height: Double = 100
    
    var click249: (() ->Void)?
    
    var body: some View {
        GeometryReader { g in
            VStack{
                VStack {
                    HStack {
                        Text("YEARLY SUBSCRIPTION")
                            .font(.custom("Livvic-Medium", size: 17))
                            .padding(.leading)
                        Spacer()
                        
                        
                        Button(action: {
                            withAnimation(.linear(duration: 0.7)) {
                                showDetails.toggle()
                                if showDetails {
                                    height = 230
                                } else {
                                    height = 100
                                }
                            }
                        }, label: {
                            Text(showDetails ? "Cancel" : "Buy")
                        })
                        .buttonStyle(.borderedProminent)
                        .tint(.red)
                        .padding([.top, .bottom, .trailing])
                        
                        Button(action: {
                            withAnimation(.linear(duration: 0.7)) {
                                expanded.toggle()
                                if expanded {
                                    offsetX = 0
                                } else {
                                    offsetX = g.size.width  * -0.75
                                    if showDetails {
                                        showDetails = false
                                        height = 100
                                    }
                                }
                            }
                        }, label: {
                            Text(expanded ? "Hide" : "Buy Now")
                        })
                        .buttonStyle(.borderedProminent)
                        .tint(.red)
                        .padding([.top, .bottom])
                    }
                    .padding()
                    if showDetails {
                        VStack{
                            Text("Yearly amount of money that you pay regularly to receive a service or magazine, or to belong to or support an organization")
                            Button {
                                click249?()
                            } label: {
                                Text("PAY $249")
                            }
                            .buttonStyle(.borderedProminent)
                            .tint(.red)
                        }
                        
                    }
                }
                .frame(minWidth: 100, idealWidth: .infinity, maxWidth: .infinity, minHeight: -200, idealHeight: height, maxHeight: height, alignment: .top)
//                    .border(Color(.lightGray), width: 2)
                .background(.ultraThinMaterial)
            }
            .offset(x: offsetX, y: 370.0)
            .onAppear(perform: {
                offsetX = g.size.width * -0.75
            })
        }
    }
}

struct PremiumView_Previews: PreviewProvider {
    static var previews: some View {
        PremiumView()
    }
}
