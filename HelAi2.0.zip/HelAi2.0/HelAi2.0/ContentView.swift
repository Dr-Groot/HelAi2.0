//
//  ContentView.swift
//  HelAi2.0
//
//  Created by Aman Pratap Singh on 06/09/23.
//

import SwiftUI
struct ContentView: View {
    
    @State private var navigateToDetailSplash = false
    
    var body: some View {
        
        NavigationView {
            ZStack {
                Color.black
                    .ignoresSafeArea()
                Image("HELAI2")
                    .renderingMode(.original)
                    
                NavigationLink("", destination: DetailSplashView(), isActive: $navigateToDetailSplash)
                    .opacity(0)
            }
            .onAppear {
                DispatchQueue.main.asyncAfter(deadline: .now() + 2, execute: {
                    navigateToDetailSplash = true
                })
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
