//
//  TextSimilarityViewModel.swift
//  HelAi2.0
//
//  Created by Aman Pratap Singh on 19/09/23.
//

import Foundation
import Combine

extension TextSimilarityView {
    @MainActor class TextSimilarityViewModel: ObservableObject {
        @Published var textField1 = ""
        @Published var textField2 = ""
        @Published var textSimilarityScore = 0.0
        @Published var showTextSimilarityLoader = false
        var responseResult: TextSimilarityModel?
        var observers: Set<AnyCancellable> = []
        
        func callTextSimilarityAPI() {
            showTextSimilarityLoader = true
            MoyaServiceProvider.homeService.requestPublisher(.textSimilarity(text1: textField1, text2: textField2))
                .sink(receiveCompletion: {completion in
                    switch completion {
                    case .finished:
                        print("Success: TEXT SIMILARITY API")
                        self.showTextSimilarityLoader = false
                    case .failure(let error):
                        print("Error: \(error)")
                    }
                }, receiveValue: {response in
                    do {
                        try self.responseResult = JSONDecoder().decode(TextSimilarityModel.self, from: response.data)
                        self.textSimilarityScore = self.responseResult?.similarity ?? 0.0
                    } catch (let error) {
                        print(error.localizedDescription)
                        print("Error: Decoding object detection response data")
                    }
                }).store(in: &observers)
        }
    }
}
