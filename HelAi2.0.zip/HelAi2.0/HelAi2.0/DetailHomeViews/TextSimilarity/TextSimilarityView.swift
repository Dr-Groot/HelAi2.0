//
//  TextSimilarityView.swift
//  HelAi2.0
//
//  Created by Aman Pratap Singh on 19/09/23.
//

import SwiftUI

struct TextSimilarityView: View {
    
    @StateObject private var viewModel = TextSimilarityViewModel()

    @State private var textField1Focus: Bool = false
    @State private var textField2Focus: Bool = false
    @State private var showNoTwoTextAlert = false
    
    var body: some View {
        LoadingView(isShowing: $viewModel.showTextSimilarityLoader, text: .constant("Processing ...")) {
            NavigationView {
                ZStack {
                    LinearGradient(gradient: Gradient(colors: [.mint, .black]), startPoint: .top, endPoint: .bottom)
                        .ignoresSafeArea()
                    
                    VStack(spacing: 15) {
                        TextField("",
                                  text: $viewModel.textField1,
                                  prompt: Text("Enter First Text").foregroundColor(.black).font(.custom("Livvic-Regular", size: 17)),
                                  axis: .vertical)
                        .lineLimit(3)
                        .autocorrectionDisabled(true)
                        .padding(.horizontal)
                        .padding(.vertical, 10)
                        .foregroundColor(.white)
                        .onTapGesture {
                            self.textField1Focus = true
                            self.textField2Focus = false
                        }
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(textField1Focus ? Color.red : Color.white, lineWidth: 2)
                        )
                        .padding(.horizontal)
                        .padding(.top, 30)

                        TextField("",
                                  text: $viewModel.textField2,
                                  prompt: Text("Enter Second Text").foregroundColor(.black).font(.custom("Livvic-Regular", size: 17)),
                                  axis: .vertical)
                        .lineLimit(3)
                        .autocorrectionDisabled(true)
                        .padding(.horizontal)
                        .padding(.vertical, 10)
                        .foregroundColor(.white)
                        .onTapGesture {
                            self.textField1Focus = false
                            self.textField2Focus = true
                        }
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(textField2Focus ? Color.red : Color.white, lineWidth: 2)
                        )
                        .padding(.horizontal)
                        
                        HStack(spacing: 20) {
                            Text("SIMILARITY: \(viewModel.textSimilarityScore, specifier: "%.2f")")
                                .frame(width: 200, height: 60)
                                .background(
                                    LinearGradient(gradient: Gradient(colors: [.black, .mint]), startPoint: .top, endPoint: .bottom)
                                )
                                .foregroundColor(.white)
                                .font(.custom("Livvic-Bold", size: 18))
                                .cornerRadius(10)

                            Button {
                                viewModel.textField1 = ""
                                viewModel.textField2 = ""
                                viewModel.textSimilarityScore = 0.0
                                dismissKeyboard()
                            } label: {
                                Image(systemName: "arrow.clockwise")
                                    .foregroundColor(.white)
                                    .font(.system(size: 25))
                            }
                        }
                        .padding(.top,20)
                        
                        
                        Button {
                            if viewModel.textField1 == "" || viewModel.textField2 == "" {
                                showNoTwoTextAlert = true
                            } else {
                                dismissKeyboard()
                                viewModel.callTextSimilarityAPI()
                            }
                        } label: {
                            Text("FIND SIMILARITY")
                                .font(.custom("Livvic-Bold", size: 17))
                                .foregroundColor(.black)
                                .padding(.horizontal, 120)
                                .padding(.vertical, 14)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 25)
                                        .stroke(Color.white, lineWidth: 3)
                                )
    //                            .aspectRatio(2, contentMode: .fit)
                        }
                        .padding(.top, 25)
                        .shadow(color: .red, radius: 10)

                        Spacer()
                    }
                    
                } // ZStack
            } // NavigationView
            .alert("No Text Found", isPresented: $showNoTwoTextAlert) {
                Button("Cancel", role: .destructive) {}
            } message: {
                Text("Please select image to for detecting Image")
            }
        }
    }  // Some View
    
    func dismissKeyboard() {
          UIApplication.shared.windows.filter {$0.isKeyWindow}.first?.endEditing(true)
    }
    
}   // Struct

struct TextSimilarityView_Previews: PreviewProvider {
    static var previews: some View {
        TextSimilarityView()
    }
}
