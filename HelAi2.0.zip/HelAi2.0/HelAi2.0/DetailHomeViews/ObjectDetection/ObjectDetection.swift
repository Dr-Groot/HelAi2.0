//
//  ObjectDetection.swift
//  HelAi2.0
//
//  Created by Aman Pratap Singh on 13/09/23.hhh
//

import SwiftUI

struct ObjectDetection: View {
    @State private var showChooseImageAlert = false
    @State var showSelection: Bool = false
    @State var showPicker: Bool = false
    @State var type: UIImagePickerController.SourceType = .photoLibrary
    @State private var image = UIImage()
    @State private var showNoImageFoundErrorAlert = false
    @State private var isUserSubscribed: Bool = false
    @State private var showBuySubscriptionAlert = false
    
    @StateObject private var viewModel = ObjectDetectionViewModel()
    
    var body: some View {
        LoadingView(isShowing: $viewModel.showObjectDetectionLoader, text: .constant("Processing ...")){
            NavigationView {
                ZStack {
                    Color.black
                        .ignoresSafeArea()
                    VStack (spacing: 25) {
                        Image(uiImage: self.image)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 300, height: 250)
                            .background(Image("noImage").resizable())
                            .foregroundColor(.mint)
                            .clipShape(RoundedRectangle(cornerRadius: 30))
                        
                        HStack {
                            Text("OBJECT DETECTION")
                                .font(.custom("Livvic-Medium", size: 23))
                                .foregroundColor(.red)
                        }
                        .font(.title3)
                        .padding(.horizontal)
                        Spacer()
                    }

                    VStack{
                        Spacer()
                        VStack(spacing: 25) {
                            
                            viewModel.objectDetectionResult.count == 0
                            ? AnyView(VStack {
                                Spacer(minLength: 400)
                                Text("NO RESULT !!")
                                    .font(.custom("Livvic-Regular", size: 20))
                                    .foregroundColor(.white)
                                Spacer()
                            })
                            : AnyView(List {
                                ForEach(viewModel.objectDetectionResult, id: \.label) {value in
                                    ObjectResultRow(label: value.label ?? "", confidence: value.confidence ?? "")
                                }
                            }
                            .background(.ultraThinMaterial)
                            .scrollContentBackground(.hidden)
                            .frame(maxWidth: .infinity,maxHeight: 220)
                            .shadow(color: .white, radius: 10)
                            .padding())
                            
                            Button {
                                viewModel.showObjectDetectionLoader = true
                                
                                if (!isUserSubscribed && viewModel.numberOfAttemptsOD == 0) {
                                    showBuySubscriptionAlert = true
                                    viewModel.showObjectDetectionLoader = false
                                } else {
                                    if self.image.size.width == 0 {
                                        showNoImageFoundErrorAlert = true
                                        viewModel.showObjectDetectionLoader = false
                                    } else if self.image.size.width >= 2000 || self.image.size.height >= 2000 {
                                        let newImage: UIImage = self.image.aspectFittedToHeight(newHeight: 900, newWidth: 900)
                                        viewModel.callObjectDetectionAPI(detectingImage: newImage)
                                    } else {
                                        viewModel.callObjectDetectionAPI(detectingImage: self.image)
                                    }
                                }
                                
                            } label: {
                                Text("Check Image")
                                    .modifier(RoundButton())
                            }
                            
                            Button {
                                showChooseImageAlert = true
                            } label: {
                                Text("Select Image")
                                    .foregroundColor(.white)
                                    .modifier(RoundButton())
                            }
                        }
                    }
                    .padding(.vertical)
                    .confirmationDialog("Change Profile Image", isPresented: $showChooseImageAlert) {
                        Button("Camera") {
                            showPicker = true
                            type = .camera
                        }
                        Button("Gallery") {
                            showPicker = true
                            type = .photoLibrary

                        }
                    } message: {
                        Text("Please select any option")
                    }
                }
                .fullScreenCover(isPresented: $showPicker) {
                    ImagePickerView(sourceType: type) { image in
                        self.image = image
                    }
                }
            }
            .toolbar {
                Button {
                    self.image = UIImage()
                    viewModel.objectDetectionResult = []
                } label: {
                    HStack {
                        Text("Reset")
                            .foregroundColor(.red)
                        Image(systemName: "repeat")
                            .foregroundColor(.red)
                    }
                }

                Button {
                    
                } label: {
                    HStack {
                        Text("Attempt:")
                            .foregroundColor(.red)

                        isUserSubscribed
                        ? AnyView(Image(systemName: "infinity")
                            .foregroundColor(.red))
                        : AnyView(Text("\(viewModel.numberOfAttemptsOD)")
                            .foregroundColor(.red))
                    }
                }
            }
            .alert("No Image Found", isPresented: $showNoImageFoundErrorAlert) {
                Button("Cancel", role: .destructive) {}
            } message: {
                Text("Please select image to for detecting Image")
            }
            .alert("Please Subscribe", isPresented: $showBuySubscriptionAlert) {
//                Button("Cancel", role: .destructive) {}
            } message: {
                Text("You finished your number of attempts")
            }
            .onAppear {
                isUserSubscribed = UserDefaults.standard.bool(forKey: "isSubscribed")
                viewModel.numberOfAttemptsOD = UserDefaults.standard.integer(forKey: "ObjectDetectionAttempt")
            }
        }
    }
}

struct ObjectResultRow: View {
    var label: String
    var confidence: String
    var body: some View {
        HStack{
            Text(label)
            Spacer()
            Text("\(confidence)%")
        }
        .shadow(color: .black, radius: 7)
        .listRowBackground(Color.red)
    }
}

struct ObjectDetection_Previews: PreviewProvider {
    static var previews: some View {
        ObjectDetection()
    }
}

extension UIImage {
    func aspectFittedToHeight(newHeight: CGFloat, newWidth: CGFloat) -> UIImage {
//        let scale = newHeight / self.size.height
//        let newWidth = self.size.width * scale
        let newSize = CGSize(width: newWidth, height: newHeight)
        let renderer = UIGraphicsImageRenderer(size: newSize)

        return renderer.image { _ in
            self.draw(in: CGRect(origin: .zero, size: newSize))
        }
    }
}
