//
//  ObjectDetectionViewModel.swift
//  HelAi2.0
//
//  Created by Aman Pratap Singh on 14/09/23.
//

import Foundation
import Combine
import UIKit

extension ObjectDetection {
    @MainActor class ObjectDetectionViewModel: ObservableObject {
        private var observers: Set<AnyCancellable> = []
        @Published var showObjectDetectionLoader = false
        @Published var objectDetectionResult: ObjectDetectionData = []
        @Published var numberOfAttemptsOD = 1
        
        func callObjectDetectionAPI(detectingImage: UIImage) {
            MoyaServiceProvider.homeService.requestPublisher(.objectDetection(image: detectingImage))
                .sink(receiveCompletion: {Completion in
                    switch Completion {
                    case .finished:
                        self.showObjectDetectionLoader = false
                        print("Success: OBJECT DETECTION API")
                    case .failure(let error):
                        print("Error: \(error)")
                    }
                }, receiveValue: { response in
                    do {
                        let objectDetectionData = try JSONDecoder().decode(ObjectDetectionData.self, from: response.data)
                        self.objectDetectionResult = objectDetectionData
                        
                        if self.numberOfAttemptsOD != 0 {
                            self.numberOfAttemptsOD -= 1
                            FirebaseHelper.shared.setUserObjectDetectionAttempt(attempt: self.numberOfAttemptsOD)
                        }
                    } catch (let error) {
                        print(error.localizedDescription)
                        print("Error: Decoding object detection response data")
                    }
                }).store(in: &observers)
        }
    }
}
