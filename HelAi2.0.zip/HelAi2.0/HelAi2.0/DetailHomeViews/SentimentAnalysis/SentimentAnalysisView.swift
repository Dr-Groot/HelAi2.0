//
//  SentimentAnalysisView.swift
//  HelAi2.0
//
//  Created by Aman Pratap Singh on 15/09/23.
//

import SwiftUI

struct SentimentAnalysisView: View {
    
    @StateObject private var viewModel = SentimentAnalysisViewModel()
    
    @State private var sentimentText: String = ""
    @State private var isUserSubscribed = false
    @State private var showBuySubscriptionAlert = false
    @State private var showNoTextAlert = false
    
    var body: some View {
        LoadingView(isShowing: $viewModel.showSentimentAnalysisLoader, text: .constant("Processing ...")) {
            NavigationView {
                ZStack {
                    Color.black
                        .ignoresSafeArea()
                    
                    VStack {
                        TextField("", text: $sentimentText,prompt: Text("Enter text here...").foregroundColor(Color.white), axis: .vertical)
                            .lineLimit(4)
                            .font(.custom("Livvic-Regular", size: 20))
                            .foregroundColor(.white)
                            .padding([.top,.bottom,.horizontal],20)
                        
                        HStack {
                            Spacer()
                            Button {
                                if sentimentText == "" {
                                    showNoTextAlert = true
                                } else {
                                    if (!isUserSubscribed && viewModel.numberOfSentimentAnalysisOD == 0) {
                                        showBuySubscriptionAlert = true
                                    } else {
                                        viewModel.callSentimentAnalysisAPI(sentimentText: sentimentText)
                                        dismissKeyboard()
                                    }
                                }
                             } label: {
                                HStack {
                                    Image(systemName: "cursorarrow.click.2")
                                    Text("SEARCH")
                                }
                                .font(.custom("Livvic-Medium", size: 20))
                                .foregroundColor(.green)
                            }
        //                    .padding(.horizontal)
                            Spacer()
                            Button {
                                viewModel.sentimentScoreValue = "---"
                                viewModel.sentimentAnalysisValue = "---"
                                sentimentText = ""
                            } label: {
                                HStack {
                                    Text("CANCEL")
                                    Image(systemName: "clear")
                                }
                            }
                            .font(.custom("Livvic-Medium", size: 20))
                            .foregroundColor(.red)
        //                    .padding(.horizontal)
                            Spacer()
                        }
                        
                        HStack {
                            Spacer()
                            VStack(spacing: 20) {
                                Text("SENTIMENT SCORE")
                                Text("SENTIMENT ANALYSIS")
                            }
                            Spacer()
                            Spacer()
                            Spacer()
                            VStack(spacing: 20){
                                Text(viewModel.sentimentScoreValue)
                                    .foregroundColor(.red)
                                Text(viewModel.sentimentAnalysisValue)
                            }
                            Spacer()
                        }
                        .padding(.top,30)
                        .foregroundColor(.white)
                        
                        Spacer()
                    }
                }
            }
            .toolbar {
                Button {

                } label: {
                    HStack {
                        Text("Attempt:")
                            .foregroundColor(.red)

                        isUserSubscribed
                        ? AnyView(Image(systemName: "infinity")
                            .foregroundColor(.red))
                        : AnyView(Text("\(viewModel.numberOfSentimentAnalysisOD)")
                            .foregroundColor(.red))
                    }
                }
                
//                ToolbarItemGroup(placement: .keyboard) {
//                    Button("Done") {
//                        textIsFocused = false
//                    }
//                }
            }
            .alert("No Text Found", isPresented: $showNoTextAlert) {
                Button("Cancel", role: .destructive) {}
            } message: {
                Text("Please select image to for detecting Image")
            }
            .alert("Please Subscribe", isPresented: $showBuySubscriptionAlert) {
                Button("Cancel", role: .destructive) {}
            } message: {
                Text("You finished your number of attempts")
            }
            .onAppear {
                isUserSubscribed = UserDefaults.standard.bool(forKey: "isSubscribed")
                viewModel.numberOfSentimentAnalysisOD = UserDefaults.standard.integer(forKey: "SentimentAnalysisAttempt")
            }
        }
    }
    
    func dismissKeyboard() {
          UIApplication.shared.windows.filter {$0.isKeyWindow}.first?.endEditing(true)
    }
}

struct SentimentAnalysisView_Previews: PreviewProvider {
    static var previews: some View {
        SentimentAnalysisView()
    }
}
