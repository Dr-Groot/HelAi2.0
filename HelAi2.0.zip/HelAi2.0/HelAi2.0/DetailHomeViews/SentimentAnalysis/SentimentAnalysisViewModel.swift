//
//  SentimentAnalysisViewModel.swift
//  HelAi2.0
//
//  Created by Aman Pratap Singh on 15/09/23.
//

import Foundation
import Combine

extension SentimentAnalysisView {
    @MainActor class SentimentAnalysisViewModel: ObservableObject {
        @Published var sentimentScoreValue: String = "---"
        @Published var sentimentAnalysisValue: String = "---"
        private var sentimentAnalysisData: SentimentAnalysisData?
        @Published var showSentimentAnalysisLoader = false
        @Published var numberOfSentimentAnalysisOD = 1
        
        private var observers: Set<AnyCancellable> = []

        func callSentimentAnalysisAPI(sentimentText: String) {
            showSentimentAnalysisLoader = true
            MoyaServiceProvider.homeService.requestPublisher(.sentimentAnalysis(text: sentimentText))
                .sink(receiveCompletion: {Completion in
                    switch Completion {
                    case .finished:
                        print("Success: SENTIMENT ANALYSIS API")
                        self.showSentimentAnalysisLoader = false
                    case .failure(let error):
                        print("Error: \(error)")
                    }
                }, receiveValue: { [self] response in
                    do {
                        try self.sentimentAnalysisData = JSONDecoder().decode(SentimentAnalysisModel.self, from: response.data)
                        self.sentimentScoreValue = "\(sentimentAnalysisData?.score ?? 0)"
                        self.sentimentAnalysisValue = sentimentAnalysisData?.sentiment ?? "~~"
                        
                        if self.numberOfSentimentAnalysisOD != 0 {
                            self.numberOfSentimentAnalysisOD -= 1
                            FirebaseHelper.shared.setSentimentAnalysisAttempt(attempt: numberOfSentimentAnalysisOD)
                        }
                    } catch (let error) {
                        print(error.localizedDescription)
                        print("Error: Decoding object detection response data")
                    }
                }).store(in: &observers)
        }
    }
}
