//
//  Constants.swift
//  HelAi2.0
//
//  Created by Aman Pratap Singh on 14/09/23.
//

import Foundation

struct Constants {
    static let baseUrl = "https://api.api-ninjas.com"
    static let apiKey = "o9NuWOHacvxJehXSOOc9Fg==4Gi7Ahr0vp5WCPwb"
    static let numberOfFreeAttempts = 4
}
