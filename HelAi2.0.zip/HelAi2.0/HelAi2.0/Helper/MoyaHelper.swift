//
//  MoyaHelper.swift
//  HelAi2.0
//
//  Created by Aman Pratap Singh on 14/09/23.
//

import Foundation
import Moya

class MoyaHelper {
    static let shared = MoyaHelper()

    private init() {}

    func getPlugins() -> [PluginType] {
        var plugins: [PluginType] = []
        #if QA
        let config = NetworkLoggerPlugin.Configuration(
            formatter: .init(responseData: jsonResponseDataFormatter),
            logOptions: [.formatRequestAscURL, .verbose]
        )
        plugins.append(NetworkLoggerPlugin(configuration: config))
        #endif
        return plugins
    }

    // MARK: Private
    private func jsonResponseDataFormatter(_ data: Data) -> String {
        do {
            let dataAsJSON = try JSONSerialization.jsonObject(with: data)
            let prettyData = try JSONSerialization.data(withJSONObject: dataAsJSON, options: .prettyPrinted)
            return String(data: prettyData, encoding: .utf8) ?? String(data: data, encoding: .utf8) ?? ""
        } catch {
            return String(data: data, encoding: .utf8) ?? ""
        }
    }
}
