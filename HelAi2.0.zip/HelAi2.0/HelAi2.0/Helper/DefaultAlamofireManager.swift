//
//  DefaultAlamofireManager.swift
//  HelAi2.0
//
//  Created by Aman Pratap Singh on 14/09/23.
//

import Foundation
import Alamofire

class DefaultAlamofireManager: Alamofire.Session {

    private(set) static var additionalHeaders: [String: String] = {
        return [
            "App-Version": "\(AppInfo.shared.buildNumber)",
            "App-Id": AppInfo.shared.bundleID,
            "User-Agent": "alamofire",
            "Client-Name": "ios"
        ]
    }()

    static let sharedManager: DefaultAlamofireManager = {
        let configuration = URLSessionConfiguration.default
        configuration.timeoutIntervalForRequest = 120 // as seconds, you can set your request timeout
        configuration.timeoutIntervalForResource = 120 // as seconds, you can set your resource timeout
        configuration.requestCachePolicy = .useProtocolCachePolicy
        configuration.httpAdditionalHeaders = additionalHeaders
        return DefaultAlamofireManager(configuration: configuration)
    }()

    static func getHeader() -> [String: String] {
        let apiKey: String = AppInfo.shared.apiKey
        var headers = additionalHeaders
        headers["X-Api-Key"] = apiKey
        return headers
    }
}
