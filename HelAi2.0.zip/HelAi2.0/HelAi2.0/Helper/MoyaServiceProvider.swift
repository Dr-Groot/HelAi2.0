//
//  MoyaServiceProvider.swift
//  HelAi2.0
//
//  Created by Aman Pratap Singh on 14/09/23.
//

import Foundation
import Moya

class MoyaServiceProvider {
    static let homeService = MoyaProvider<HomeServices>(
        session: DefaultAlamofireManager.sharedManager,
        plugins: MoyaHelper.shared.getPlugins()
    )
}
