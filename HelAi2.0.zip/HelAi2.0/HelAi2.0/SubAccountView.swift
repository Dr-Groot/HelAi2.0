//
//  SubAccountView.swift
//  HelAi2.0
//
//  Created by Aman Pratap Singh on 13/09/23.
//

import SwiftUI
import Firebase

struct SubAccountView: View {
    @State private var showChangeImageAlert = false
    @State var showSelection: Bool = false
    @State var showPicker: Bool = false
    @State var type: UIImagePickerController.SourceType = .photoLibrary
    @State private var image = UIImage()
    var body: some View {
        
        VStack {
            HStack(){
                Image(uiImage: self.image)
                    .resizable()
                    .clipped()
                    .frame(width: 130, height: 130,alignment: .center)
                    .background(Image("HELAI2").resizable())
                    .clipShape(Circle())
                    .overlay(
                        Text("Edit")
                            .background(.black)
                            .padding(3),
                        alignment: .bottom)
                    .foregroundColor(.white)
                    .onTapGesture {
                        showChangeImageAlert = true
                    }
            }
            Text("HELAI")
                .font(.title.bold())
            Text("\(FirebaseAuth.Auth.auth().currentUser?.email ?? "No User Found")")
                .font(.subheadline)
            Form {
                Section {
                    Text("Name, Phone Numbers, Email")
                    Text("Password & Security")
                    Text("Payment & Shipping")
                    Text("Subscriptions")
                }
            }
            .confirmationDialog("Change Profile Image", isPresented: $showChangeImageAlert) {
                Button("Camera") {
                    showPicker = true
                    type = .camera
                }
                Button("Gallery") {
                    showPicker = true
                    type = .photoLibrary

                }
            } message: {
                Text("Please select any option")
            }
            Spacer()
            Spacer()
        }
        .fullScreenCover(isPresented: $showPicker) {
            ImagePickerView(sourceType: type) { image in
                self.image = image
            }
        }
        
//        Form {
//            Section {
//                VStack {
//                    HStack(){
//                        Spacer()
//                        Image("HELAI2")
//                            .resizable()
//                            .clipped()
//                            .frame(width: 130, height: 130,alignment: .center)
//                            .clipShape(Circle())
//                            .overlay(
//                                Text("Edit")
//                                    .background(.black)
//                                    .padding(3),
//                                alignment: .bottom)
//                            .foregroundColor(.white)
//                            .onTapGesture {
//                                showChangeImageAlert = true
//                            }
//                        Spacer()
//                    }
//                    Text("HELAI")
//                        .font(.title.bold())
//                    Text("\(FirebaseAuth.Auth.auth().currentUser?.email ?? "No User Found")")
//                        .font(.subheadline)
//                }
//            }
//        }
//        .confirmationDialog("Change Profile Image", isPresented: $showChangeImageAlert) {
//            Button("Camera") {
//
//            }
//            Button("Gallery") {
//
//            }
//        } message: {
//            Text("Please select any option")
//        }
//        .scrollContentBackground(.hidden)
    }
}

struct SubAccountView_Previews: PreviewProvider {
    static var previews: some View {
        SubAccountView()
    }
}
