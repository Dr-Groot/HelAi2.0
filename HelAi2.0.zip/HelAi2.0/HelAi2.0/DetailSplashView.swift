//
//  DetailSplashView.swift
//  HelAi2.0
//
//  Created by Aman Pratap Singh on 06/09/23.
//

import SwiftUI
import Lottie
import Firebase

struct DetailSplashView: View {
    
    @State private var aiColor = Color.white
    @State private var navigateToLandingPageView = false
    @State private var moveToTabBar = false
    
    var body: some View {
        
        NavigationView {
            ZStack {
                Color.black
                    .ignoresSafeArea()
                LottieView(lottieFile: "helAISplash")
                VStack(spacing: 3) {
                    
                    HStack(spacing:0) {
                        
                        Text("Hel")
                            .font(.largeTitle)
                            .foregroundColor(.white)
                        
                        Text("AI")
                            .font(.largeTitle)
                            .foregroundColor(.white)
                            .colorMultiply(aiColor)
                            .onAppear{
                                withAnimation(.easeInOut(duration: 3)) {
                                    self.aiColor = Color.red
                                }
                            }
                    }
                    
                    Text("2.0")
                        .font(.subheadline.bold())
                        .foregroundColor(.red)
                }
                
                NavigationLink(
                    "",
                    destination: LandingPageView(),
                    isActive: $navigateToLandingPageView
                )
                .opacity(0)
                
                NavigationLink(
                    "",
                    destination: TabBarView(),
                    isActive: $moveToTabBar
                )
                .opacity(0)
                    
            }
        }
        .navigationBarBackButtonHidden(true)
        .onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now() + 3, execute: {
                if FirebaseAuth.Auth.auth().currentUser != nil {
                    FirebaseHelper.shared.getIsUserSubscribed()
                    FirebaseHelper.shared.getUserObjectDetectionAttempt()
                    FirebaseHelper.shared.getSentimentAnalysisAttempt()
                    moveToTabBar = true
                } else {
                    navigateToLandingPageView = true
                }
                
            })
        }
    }
}

struct DetailSplashView_Previews: PreviewProvider {
    static var previews: some View {
        DetailSplashView()
    }
}
