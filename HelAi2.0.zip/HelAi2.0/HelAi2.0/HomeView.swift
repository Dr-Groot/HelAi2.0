//
//  HomeView.swift
//  HelAi2.0
//
//  Created by Aman Pratap Singh on 06/09/23.
//

import SwiftUI
import Firebase

struct HomeView: View {
    
    @State private var isRotating = 0.0
    @State private var moveToObjectDetectionView = false
    @State private var moveToSentimentAnalysisView = false
    @State private var moveToTextSimilarityView = false
    
    var body: some View {
        NavigationView {
            ZStack {
                Color.white
                    .ignoresSafeArea()
                
                RadialGradient(stops: [
                    .init(color: .black, location: 0.3),
                    .init(color: .mint, location: 0.3),
                ], center: .top, startRadius: 280, endRadius: 600)
                .ignoresSafeArea()
                
                VStack {
                    Spacer()
                    Image("HELAI2")
                        .onAppear {
                          
                        }
                    
                    HStack (spacing: 30) {
                        VStack (spacing: 30) {
                            VStack {
                                Button {
                                    moveToObjectDetectionView = true
                                } label: {
                                    Image("od")
                                }
                                .padding(30)
                                .background(
                                        Circle()
                                            .fill(Color.white)
                                            .shadow(color: Color.black.opacity(0.3), radius: 10, x: 10, y: 10)
                                            .shadow(color: Color.white.opacity(0.7), radius: 10, x: -5, y: -5)
                                    )
                                .rotationEffect(.degrees(isRotating))
                                            .onAppear {
                                                withAnimation(.linear(duration: 1)
                                                    .speed(0.15).repeatForever(autoreverses: false)) {
                                                    isRotating = 360.0
                                                }
                                            }
                                Text("OBJECT DETECTION")
                                    .foregroundColor(.black)
                                    .font(.custom("Livvic-Medium", size: 18))
                            }
                            
                            VStack {
                                Button {
                                    
                                } label: {
                                    Image("tts")
                                }
                                .padding(30)
                                .background(
                                        Circle()
                                            .fill(Color.white)
                                            .shadow(color: Color.black.opacity(0.3), radius: 10, x: 10, y: 10)
                                            .shadow(color: Color.white.opacity(0.7), radius: 10, x: -5, y: -5)
                                    )
                                .rotationEffect(.degrees(isRotating))
                                            .onAppear {
                                                withAnimation(.linear(duration: 1)
                                                    .speed(0.15).repeatForever(autoreverses: false)) {
                                                    isRotating = 360.0
                                                }
                                            }
                                Text("IMAGE TO TEXT")
                                    .foregroundColor(.black)
                                    .font(.custom("Livvic-Medium", size: 18))
                            }
                        }
    //                    V1
                        VStack (spacing: 30) {
                            VStack {
                                Button {
                                    moveToTextSimilarityView = true
                                } label: {
                                    Image("tts")
                                }
                                .padding(30)
                                .background(
                                        Circle()
                                            .fill(Color.white)
                                            .shadow(color: Color.black.opacity(0.3), radius: 10, x: 10, y: 10)
                                            .shadow(color: Color.white.opacity(0.7), radius: 10, x: -5, y: -5)
                                    )
                                .rotationEffect(.degrees(isRotating))
                                            .onAppear {
                                                withAnimation(.linear(duration: 1)
                                                    .speed(0.15).repeatForever(autoreverses: false)) {
                                                    isRotating = 360.0
                                                }
                                            }
                                
                                Text("TEXT SIMILARITY")
                                    .foregroundColor(.black)
                                    .font(.custom("Livvic-Medium", size: 18))
                            }
                            
                            VStack {
                                Button {
                                    moveToSentimentAnalysisView = true
                                } label: {
                                    Image("sa")
                                }
                                .padding(30)
                                .background(
                                        Circle()
                                            .fill(Color.white)
                                            .shadow(color: Color.black.opacity(0.3), radius: 10, x: 10, y: 10)
                                            .shadow(color: Color.white.opacity(0.7), radius: 10, x: -5, y: -5)
                                    )
                                .rotationEffect(.degrees(isRotating))
                                            .onAppear {
                                                withAnimation(.linear(duration: 1)
                                                    .speed(0.15).repeatForever(autoreverses: false)) {
                                                    isRotating = 360.0
                                                }
                                            }
                                Text("SENTIMENT ANALYSIS")
                                    .foregroundColor(.black)
                                    .font(.custom("Livvic-Medium", size: 18))
                            }
                        }
//                    V2
                    }
//                H
                    Spacer()
                    Spacer()
                }
//              V
                NavigationLink("", destination: ObjectDetection(), isActive: $moveToObjectDetectionView)
                NavigationLink("", destination: SentimentAnalysisView(),isActive: $moveToSentimentAnalysisView)
                NavigationLink("", destination: TextSimilarityView(),isActive: $moveToTextSimilarityView)
            }
//          Z
        }
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
