//
//  SentimentAnalysisModel.swift
//  HelAi2.0
//
//  Created by Aman Pratap Singh on 18/09/23.
//

import Foundation

struct SentimentAnalysisModel: Codable {
    let score: Double?
    let text: String?
    let sentiment: String?
    
    init(score: Double?, text: String?, sentiment: String?) {
        self.score = score
        self.text = text
        self.sentiment = sentiment
    }
    
    enum CodingKeys: String, CodingKey {
        case score
        case text
        case sentiment
    }
}

typealias SentimentAnalysisData = SentimentAnalysisModel
