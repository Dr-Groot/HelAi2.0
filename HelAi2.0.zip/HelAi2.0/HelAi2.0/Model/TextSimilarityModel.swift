//
//  TextSimilarityModel.swift
//  HelAi2.0
//
//  Created by Aman Pratap Singh on 19/09/23.
//

import Foundation

struct TextSimilarityModel: Codable {
    let similarity: Double?
    
    init(similarity: Double? = nil) {
        self.similarity = similarity
    }
    
    enum CodingKeys: String, CodingKey {
        case similarity
    }
}
