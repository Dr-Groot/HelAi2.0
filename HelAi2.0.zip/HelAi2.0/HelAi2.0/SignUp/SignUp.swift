//
//  SignUp.swift
//  HelAi2.0
//
//  Created by Aman Pratap Singh on 08/09/23.
//

import SwiftUI
import Combine

struct SignUp: View {
    
    @State private var emailtText = ""
    @State private var passwordText = ""
    @FocusState private var textIsFocused: Bool
    @StateObject private var viewModel = SignUpViewModel()
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>

    var body: some View {
        LoadingView(isShowing: $viewModel.showLoader , text: .constant("Creating Account ...")) {
            NavigationView {
                ZStack {
                    Color.black
                        .ignoresSafeArea()
                    
                    LottieView(lottieFile: "diamondLines")
                    
                    VStack(alignment:.leading) {
                                    HStack {
                                        Button {
                                            self.presentationMode.wrappedValue.dismiss()
                                        } label: {
                                            Image(systemName: "arrowshape.backward.fill")
                                                .foregroundColor(.red)
                                                .frame(width: 50, height: 50)
                                        }
                                        .background(.ultraThinMaterial)
                                        .mask(Circle())
                                        .frame(width: 80, height: 60)
                                        Spacer()
                                    }
                                    Spacer()
                                }
                    
                    VStack(spacing: 40) {
                        
                        Text("SIGN UP")
                            .font(.title.bold())
                            .foregroundColor(.white)
            
                        VStack(spacing: 20){
                            TextField("",
                                      text: $emailtText,
                                      prompt: Text("Email").foregroundColor(Color.white)
                            )
                            .modifier(RoundTextField())
                            .focused($textIsFocused)
                            .autocorrectionDisabled(true)
                            .autocapitalization(.none)
                            
                            SecureField("",
                                      text: $passwordText,
                                      prompt: Text("Password").foregroundColor(Color.white)
                            )
                            .modifier(RoundTextField())
                            .focused($textIsFocused)
                            .autocorrectionDisabled(true)
                        }
                        
                        Button {
                            FirebaseHelper.shared.createUserAccount(email: emailtText, password: passwordText)
                            viewModel.showLoader = true
                        } label: {
                             Text("Sign Up")
                                .modifier(RoundButton())
                        }
                    }
                    
                    NavigationLink(
                        "",
                        destination: TabBarView(),
                        isActive: $viewModel.moveToTabBar
                    ).opacity(0)
                }
                .alert("Bad Entries", isPresented: $viewModel.showRetryAlert) {
                    Button("Retry", role: .destructive) {}
                } message: {
                    Text("Retry again")
                }
                .onAppear {
                    viewModel.checkSignUpResponse()
                }
            }
            .navigationBarBackButtonHidden(true)
//            .navigationBarItems(leading: btnBack)
            .toolbar {
                ToolbarItemGroup(placement: .keyboard) {
                    Spacer()
                    Button("Done") {
                        textIsFocused = false
                    }
                }
            }
        }
    }
}

struct SignUp_Previews: PreviewProvider {
    static var previews: some View {
        SignUp()
    }
}
