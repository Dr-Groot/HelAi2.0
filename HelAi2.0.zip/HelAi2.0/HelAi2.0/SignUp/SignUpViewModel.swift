//
//  SignUpViewModel.swift
//  HelAi2.0
//
//  Created by Aman Pratap Singh on 08/09/23.
//

import Foundation
import Combine

extension SignUp {
    @MainActor class SignUpViewModel: ObservableObject {
        
        var observer: [AnyCancellable] = []
        
        @Published var moveToTabBar = false
        @Published var showRetryAlert = false
        @Published var showLoader = false
        
            func checkSignUpResponse() {
                FirebaseHelper.shared.accountCreateResponse
                    .sink(receiveValue: { value in
                        if value {
                            FirebaseHelper.shared.setUserSubscription(subcribed: false)
                            FirebaseHelper.shared.setUserObjectDetectionAttempt(attempt: Constants.numberOfFreeAttempts)
                            FirebaseHelper.shared.setSentimentAnalysisAttempt(attempt: Constants.numberOfFreeAttempts)
                            FirebaseHelper.shared.getIsUserSubscribed()
                            self.moveToTabBar = true
                            self.showLoader = false
                        } else {
                            self.showRetryAlert = true
                            self.showLoader = false
                        }
                    }).store(in: &observer)
            }
    }
}
