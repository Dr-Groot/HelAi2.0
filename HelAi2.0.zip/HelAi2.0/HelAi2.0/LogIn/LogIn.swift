//
//  LogIn.swift
//  HelAi2.0
//
//  Created by Aman Pratap Singh on 08/09/23.
//

import SwiftUI

struct LogIn: View {
    @State private var emailtTextField = ""
    @State private var passwordTextField = ""
    @FocusState private var textIsFocused: Bool
    @StateObject private var viewModel = LogInViewModel()
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>

    var body: some View {
        LoadingView(isShowing: $viewModel.showSignInLoader, text: .constant("Signing In ...")){
            NavigationView {
                ZStack {
                    Color.black
                        .ignoresSafeArea()
                    
                    LottieView(lottieFile: "diamondLines")
                    
                    VStack(alignment:.leading) {
                                HStack {
                                    Button {
                                        self.presentationMode.wrappedValue.dismiss()
                                    } label: {
                                        Image(systemName: "arrowshape.backward.fill")
                                            .foregroundColor(.red)
                                            .frame(width: 50, height: 50)
                                    }
                                    .background(.ultraThinMaterial)
                                    .mask(Circle())
                                    .frame(width: 80, height: 60)
                                    Spacer()
                                }
                                Spacer()
                            }
                    
                    VStack(spacing: 40) {
                        Text("LOG IN")
                            .font(.title.bold())
                            .foregroundColor(.white)
            
                        VStack(spacing: 20){
                            TextField("",
                                      text: $emailtTextField,
                                      prompt: Text("Email").foregroundColor(Color.white)
                            )
                            .modifier(RoundTextField())
                            .focused($textIsFocused)
                            .autocapitalization(.none)
                            
                            SecureField("",
                                      text: $passwordTextField,
                                      prompt: Text("Password").foregroundColor(Color.white)
                            )
                            .modifier(RoundTextField())
                            .focused($textIsFocused)
                        }
                        
                        VStack(spacing: 13){
                            Button {
                                viewModel.showSignInLoader = true
                                FirebaseHelper.shared.userLogIn(email: emailtTextField, password: passwordTextField)
                            } label: {
                                 Text("Log In")
                                    .modifier(RoundButton())
                            }
                            
                            Button {
                                
                            } label: {
                                Text("Forgot Password !")
                                    .foregroundColor(.white)
                            }
                        }
                    }
                    NavigationLink(
                        "",
                        destination: TabBarView(),
                        isActive: $viewModel.moveToTabBar
                    ).opacity(0)
                }
                .alert("Bad Entries", isPresented: $viewModel.showWrongEntryAlert) {
                    Button("Retry", role: .destructive) {}
                } message: {
                    Text("Retry again")
                }
                .onAppear {
                    viewModel.checkLogInResponse()
                 }
            }
            .navigationBarBackButtonHidden(true)
//            .navigationBarItems(leading: btnBack)
            .toolbar {
                ToolbarItemGroup(placement: .keyboard) {
                    Spacer()
                    Button("Done") {
                        textIsFocused = false
                    }
                }
            }
        }
    }
}

struct LogIn_Previews: PreviewProvider {
    static var previews: some View {
        LogIn()
    }
}
