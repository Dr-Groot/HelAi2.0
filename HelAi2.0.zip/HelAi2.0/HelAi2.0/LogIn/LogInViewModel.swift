//
//  LogInViewModel.swift
//  HelAi2.0
//
//  Created by Aman Pratap Singh on 11/09/23.
//

import Foundation
import Combine

extension LogIn {
    @MainActor class LogInViewModel: ObservableObject {
        
        @Published var showWrongEntryAlert = false
        @Published var moveToTabBar = false
        @Published var showSignInLoader = false
        
        var observers: Set<AnyCancellable> = []
        
        func checkLogInResponse() {
            FirebaseHelper.shared.userLogInResponse
                .sink(receiveValue: {value in
                    if value {
                        FirebaseHelper.shared.getIsUserSubscribed()
                        FirebaseHelper.shared.getUserObjectDetectionAttempt()
                        FirebaseHelper.shared.getSentimentAnalysisAttempt()
                        self.moveToTabBar = true
                        self.showSignInLoader = false
                    } else {
                        self.showWrongEntryAlert = true
                        self.showSignInLoader = false
                    }
                }).store(in: &observers)
        }
    }
}
