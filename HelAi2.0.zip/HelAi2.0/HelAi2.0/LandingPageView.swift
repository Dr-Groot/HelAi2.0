//
//  LandingPageView.swift
//  HelAi2.0
//
//  Created by Aman Pratap Singh on 06/09/23.
//

import SwiftUI

struct LandingPageView: View {
    
    @State private var movingToLogin = false
    @State private var movingToSignUp = false
    
    var body: some View {
        NavigationView {
            ZStack {
                Color.black
                    .ignoresSafeArea()
                
                LottieView(lottieFile: "diamondLines")
                
                VStack {
                    Image("HELAI2")
                    
                    VStack(spacing: 25) {
                        Button {
                            movingToSignUp = true
                        } label: {
                            Text("Sign In")
                                .modifier(RoundButton())
                        }
                        
                        Button {
                            movingToLogin = true
                        } label: {
                            Text("Log In")
                                .modifier(RoundButton())
                        }
                    }
                    
                }
                
                NavigationLink(
                    "",
                    destination: SignUp(),
                    isActive: $movingToSignUp
                ).opacity(0)
                
                NavigationLink(
                    "",
                    destination: LogIn(),
                    isActive: $movingToLogin
                ).opacity(0)
            }
            
        }
        .navigationBarBackButtonHidden(true)
    }
}

struct LandingPageView_Previews: PreviewProvider {
    static var previews: some View {
        LandingPageView()
    }
}
