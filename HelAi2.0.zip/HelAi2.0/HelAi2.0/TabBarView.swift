//
//  TabBarView.swift
//  HelAi2.0
//
//  Created by Aman Pratap Singh on 11/09/23.
//

import SwiftUI

enum Tab {
    case Home
    case Premium
    case Account
}

struct TabBarView: View {
    
    init() {
        UITabBar.appearance().backgroundColor = UIColor.white
        UITabBar.appearance().unselectedItemTintColor = UIColor.black
      }

    var body: some View {
        TabView {
           HomeView()
                .tabItem {
                    Label("Home", systemImage: "homekit")
                }
                .tag(Tab.Home)
            
            PremiumView()
                .tabItem {
                    Label("Premium", systemImage: "crown.fill")
                }
                .tag(Tab.Premium)

            AccountView()
                 .tabItem {
                     Label("Account", systemImage: "person")
                 }
                 .tag(Tab.Account)
        }
        .accentColor(.red)
        .navigationBarBackButtonHidden(true)
    }
}

struct TabBarView_Previews: PreviewProvider {
    static var previews: some View {
        TabBarView()
    }
}
