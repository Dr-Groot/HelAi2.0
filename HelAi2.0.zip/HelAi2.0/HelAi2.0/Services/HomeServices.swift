//
//  ObjectDetectionServices.swift
//  HelAi2.0
//
//  Created by Aman Pratap Singh on 14/09/23.
//

import Foundation
import Moya

enum HomeServices {
    case imageToText(image: UIImage)
    case objectDetection(image: UIImage)
    case sentimentAnalysis(text: String)
    case textSimilarity(text1: String, text2: String)
}

extension HomeServices: TargetType {
    var baseURL: URL {
        guard let url = URL(string: AppInfo.shared.apiBaseUrl) else { fatalError() }
        return url
    }
    
    var path: String {
        switch self {
        case .imageToText:
            return "/v1/imagetotext"
        case .objectDetection:
            return "/v1/objectdetection"
        case .sentimentAnalysis:
            return "/v1/sentiment"
        case .textSimilarity:
            return "/v1/textsimilarity"
        }
    }
    
    var method: Moya.Method {
        switch self {
        case .imageToText:
            return .post
        case .objectDetection:
            return .post
        case .sentimentAnalysis:
            return .get
        case .textSimilarity:
            return .post
        }
    }
    
    var task: Moya.Task {
        switch self {
        case let .imageToText(img):
            let imageData = img.jpegData(compressionQuality: 0.5)!
            let pictureData = MultipartFormData(provider: .data(imageData), name: "image")
            let multipartData = [pictureData]
            return .uploadMultipart(multipartData)
            
        case let .objectDetection(img):
            let imageData = img.jpegData(compressionQuality: 0.5)!
            let pictureData = MultipartFormData(provider: .data(imageData), name: "image")
            let multipartData = [pictureData]
            return .uploadMultipart(multipartData)
        case let .sentimentAnalysis(text):
            return .requestParameters(
                parameters: [
                    "text": text
                ],
                encoding: URLEncoding.queryString
            )
        case let .textSimilarity(text1, text2):
            return .requestParameters(
                parameters: [
                    "text_1": text1,
                    "text_2": text2
                ],
                encoding: JSONEncoding.default
            )
        }
    }
    
    var headers: [String : String]? {
        switch self {
        case .imageToText, .objectDetection, .sentimentAnalysis, .textSimilarity:
            return DefaultAlamofireManager.getHeader()
        }
    }
}

